﻿using System.Windows;

namespace WpfExampleMVVM.Views;

public partial class MainView : Window
{
    public MainView()
    {
        InitializeComponent();
    }
}
